import librosa
import numpy as np
import os

# Set paths to clean and noisy audio files
clean_path = '/path/to/clean/audio/files/'
noisy_path = '/path/to/noisy/audio/files/'

# Load audio files and extract features
clean_files = os.listdir(clean_path)
noisy_files = os.listdir(noisy_path)

for i in range(len(clean_files)):
    # Load clean audio file
    clean_audio, sr = librosa.load(clean_path + clean_files[i], sr=16000)

    # Load noisy audio file
    noisy_audio, sr = librosa.load(noisy_path + noisy_files[i], sr=16000)

    # Extract features using MFCCs
    clean_mfcc = librosa.feature.mfcc(y=clean_audio, sr=sr, n_mfcc=40)
    noisy_mfcc = librosa.feature.mfcc(y=noisy_audio, sr=sr, n_mfcc=40)

    # Save features to file
    np.save('/path/to/features/clean/' + clean_files[i] + '.npy', clean_mfcc)
    np.save('/path/to/features/noisy/' + noisy_files[i] + '.npy', noisy_mfcc)
